
export type RoomStyle = 
  | 'Modern Minimalist' 
  | 'Bohemian' 
  | 'Industrial' 
  | 'Scandi' 
  | 'Cozy Clutter-Free' 
  | 'Mid-Century Modern' 
  | 'Japandi' 
  | 'Art Deco' 
  | 'Coastal' 
  | 'Modern Farmhouse' 
  | 'Biophilic' 
  | 'Cyberpunk';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}

export interface DeclutterTask {
  id: string;
  zone: string;
  task: string;
  timeEstimate: string; // e.g., "5 mins"
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface AnalysisResult {
  markdown: string;
  tasks: DeclutterTask[];
}

export interface ImageState {
  file: File | null;
  previewUrl: string | null;
  base64: string | null;
  mimeType: string | null;
  selectedStyle: RoomStyle;
}
