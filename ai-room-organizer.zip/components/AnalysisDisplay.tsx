
import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { Sparkles, Loader2, ArrowRight, Image as ImageIcon, FileText, Wand2, CheckCircle2, ListTodo, Circle, Clock, ScanLine } from 'lucide-react';
import ComparisonSlider from './ComparisonSlider';
import Timer from './Timer';
import { DeclutterTask } from '../types';

interface AnalysisDisplayProps {
  analysis: { markdown: string; tasks: DeclutterTask[] } | null;
  generatedImage: string | null;
  originalImage: string | null;
  isAnalyzing: boolean;
  onStartAnalysis: () => void;
  hasImage: boolean;
}

const LOADING_STEPS = [
    "Initializing spatial scan...",
    "Mapping room geometry...",
    "Identifying clutter clusters...",
    "Analyzing lighting & texture...",
    "Generating Zen transformation...",
    "Finalizing organizational plan..."
];

const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ analysis, generatedImage, originalImage, isAnalyzing, onStartAnalysis, hasImage }) => {
  const [activeTab, setActiveTab] = useState<'plan' | 'visual' | 'checklist'>('plan');
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());
  const [loadingStepIndex, setLoadingStepIndex] = useState(0);

  // Cycle through loading steps
  useEffect(() => {
    if (isAnalyzing) {
        setLoadingStepIndex(0);
        const interval = setInterval(() => {
            setLoadingStepIndex(prev => (prev + 1) % LOADING_STEPS.length);
        }, 1500);
        return () => clearInterval(interval);
    }
  }, [isAnalyzing]);

  const toggleTask = (taskId: string) => {
    const newCompleted = new Set(completedTasks);
    if (newCompleted.has(taskId)) {
      newCompleted.delete(taskId);
    } else {
      newCompleted.add(taskId);
    }
    setCompletedTasks(newCompleted);
  };

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Easy': return 'bg-green-100 text-green-700';
      case 'Medium': return 'bg-yellow-100 text-yellow-700';
      case 'Hard': return 'bg-red-100 text-red-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  if (isAnalyzing) {
    return (
      <div className="glass-panel h-full min-h-[400px] flex flex-col items-center justify-center p-8 text-center space-y-8 rounded-3xl animate-fade-in relative overflow-hidden">
        {/* Background Animation */}
        <div className="absolute inset-0 bg-gradient-to-t from-teal-50/50 to-transparent"></div>
        
        <div className="relative z-10">
            <div className="relative w-24 h-24 mx-auto mb-6">
                 {/* Spinning Outer Ring */}
                <div className="absolute inset-0 border-4 border-teal-100 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-t-teal-500 rounded-full animate-spin"></div>
                
                {/* Inner Icon */}
                <div className="absolute inset-0 flex items-center justify-center text-teal-600">
                    <ScanLine size={32} className="animate-pulse"/>
                </div>
            </div>
            
            <h3 className="text-xl font-bold text-slate-800 tracking-tight">System Active</h3>
            <p className="text-teal-600 text-sm font-mono mt-2 font-medium min-h-[20px] transition-all duration-300">
                {LOADING_STEPS[loadingStepIndex]}
            </p>
        </div>
        
        <div className="w-64 h-1.5 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-teal-500 rounded-full animate-[width_2s_ease-in-out_infinite] w-[30%]"></div>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="glass-panel h-full min-h-[400px] flex flex-col items-center justify-center p-8 text-center space-y-8 rounded-3xl">
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-tr from-teal-200 to-blue-200 rounded-full blur-xl opacity-0 group-hover:opacity-60 transition-opacity duration-700"></div>
          <div className="w-20 h-20 bg-gradient-to-br from-teal-50 to-white rounded-2xl flex items-center justify-center shadow-lg border border-white/50 relative z-10">
              <Wand2 className="w-10 h-10 text-teal-600" />
          </div>
        </div>
        
        <div className="space-y-4 max-w-sm mx-auto">
            <h3 className="text-2xl font-bold text-slate-800 tracking-tight">Visualize Calm</h3>
            <p className="text-slate-600 leading-relaxed">
              Transform chaos into calm. Upload a photo to get a <b>comparison view</b>, a step-by-step plan, and a <b>focus timer</b>.
            </p>
        </div>
        
        <button
          onClick={onStartAnalysis}
          disabled={!hasImage}
          className={`
            flex items-center gap-3 px-8 py-4 rounded-xl font-bold text-base transition-all duration-300 shadow-lg w-full sm:w-auto justify-center
            ${hasImage 
              ? 'bg-gradient-to-r from-teal-600 to-teal-500 text-white hover:translate-y-[-2px] hover:shadow-teal-500/30 ring-4 ring-teal-500/10' 
              : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'}
          `}
        >
          {hasImage ? "Start Room Scan" : "Upload to Start"} <ArrowRight size={20} />
        </button>
      </div>
    );
  }

  return (
    <div className="glass-panel rounded-3xl overflow-hidden h-full flex flex-col animate-fade-in ring-1 ring-white/60">
      {/* Header with Tabs - Horizontal Scroll on Mobile */}
      <div className="px-4 sm:px-6 py-4 border-b border-slate-200/60 bg-white/40 backdrop-blur-md flex items-center justify-between flex-wrap gap-4 z-20">
        <div className="flex items-center gap-2">
          <div className="bg-teal-100/80 p-1.5 rounded-lg border border-teal-200/50">
            <Sparkles className="w-4 h-4 text-teal-700" />
          </div>
          <h2 className="text-base sm:text-lg font-bold text-slate-800">Your Zen Plan</h2>
        </div>

        {generatedImage && (
          <div className="flex bg-slate-100/80 p-1 rounded-xl shadow-inner overflow-x-auto max-w-full scrollbar-hide">
            <button
              onClick={() => setActiveTab('plan')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === 'plan' 
                  ? 'bg-white text-slate-800 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <FileText size={16} /> <span className="inline">Overview</span>
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === 'checklist' 
                  ? 'bg-white text-teal-700 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <ListTodo size={16} /> <span className="inline">Tasks</span>
            </button>
            <button
              onClick={() => setActiveTab('visual')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === 'visual' 
                  ? 'bg-white text-purple-700 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <ImageIcon size={16} /> <span className="hidden sm:inline">Before & After</span>
            </button>
          </div>
        )}
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar bg-white/30 relative">
        
        {/* Visual Tab */}
        {activeTab === 'visual' && generatedImage && originalImage && (
           <div className="p-4 sm:p-6 h-full flex flex-col justify-start">
              <ComparisonSlider originalImage={originalImage} generatedImage={generatedImage} />
              <div className="mt-8 p-4 bg-white/60 rounded-xl border border-white/60">
                <h4 className="font-semibold text-slate-800 flex items-center gap-2 mb-2">
                  <CheckCircle2 size={18} className="text-teal-600"/> Why this works
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed">
                  The AI has removed visual clutter while maintaining your room's structural integrity. Notice how clear surfaces and organized storage creates a sense of spaciousness.
                </p>
              </div>
           </div>
        )}

        {/* Checklist Tab */}
        {activeTab === 'checklist' && (
          <div className="p-4 sm:p-6 space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold text-slate-800 text-lg flex items-center gap-2">
                  <ListTodo size={20} className="text-teal-600"/> Action Items
                </h3>
                <div className="space-y-3">
                  {analysis.tasks.map((task, i) => {
                    const isDone = completedTasks.has(task.id);
                    return (
                      <div 
                        key={task.id || i}
                        onClick={() => toggleTask(task.id)}
                        className={`group p-4 rounded-xl border transition-all cursor-pointer relative overflow-hidden ${
                          isDone 
                            ? 'bg-teal-50 border-teal-200 opacity-75' 
                            : 'bg-white border-white/60 hover:border-teal-200 hover:shadow-md'
                        }`}
                      >
                        <div className="flex items-start gap-4 relative z-10">
                          <div className={`mt-1 transition-colors ${isDone ? 'text-teal-600' : 'text-slate-300 group-hover:text-teal-400'}`}>
                            {isDone ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{task.zone}</span>
                              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${getDifficultyColor(task.difficulty)}`}>
                                {task.difficulty}
                              </span>
                            </div>
                            <p className={`font-medium transition-all ${isDone ? 'text-slate-500 line-through' : 'text-slate-800'}`}>
                              {task.task}
                            </p>
                            <div className="flex items-center gap-1.5 mt-2 text-xs text-slate-500">
                              <Clock size={12} /> {task.timeEstimate}
                            </div>
                          </div>
                        </div>
                        {isDone && <div className="absolute inset-0 bg-teal-500/5 pointer-events-none" />}
                      </div>
                    );
                  })}
                  {analysis.tasks.length === 0 && (
                     <div className="text-center py-8 text-slate-500">No specific tasks generated. Check the overview!</div>
                  )}
                </div>
              </div>

              {/* Timer Column */}
              <div className="space-y-6">
                <Timer />
                
                <div className="bg-indigo-50/80 border border-indigo-100 rounded-2xl p-5">
                  <h4 className="font-bold text-indigo-900 mb-2">Gamify your cleaning</h4>
                  <p className="text-sm text-indigo-700/80 leading-relaxed mb-4">
                    Set the timer for 15 minutes and try to clear as many "Easy" tasks as possible before the buzzer sounds. This technique (Pomodoro) reduces overwhelm!
                  </p>
                  <div className="w-full bg-white rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full transition-all duration-500" 
                      style={{ width: `${(completedTasks.size / (analysis.tasks.length || 1)) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-2 text-xs font-bold text-indigo-400">
                    <span>Progress</span>
                    <span>{Math.round((completedTasks.size / (analysis.tasks.length || 1)) * 100)}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Overview Tab */}
        {activeTab === 'plan' && (
          <div className="p-6 sm:p-8 prose prose-slate prose-headings:text-slate-800 prose-headings:font-bold prose-p:text-slate-700 prose-a:text-teal-600 prose-strong:text-teal-800 max-w-none text-sm sm:text-base">
            <ReactMarkdown>{analysis.markdown}</ReactMarkdown>
          </div>
        )}

      </div>
    </div>
  );
};

export default AnalysisDisplay;
