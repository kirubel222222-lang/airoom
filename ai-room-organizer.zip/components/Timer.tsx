
import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Timer as TimerIcon } from 'lucide-react';

const Timer: React.FC = () => {
  const INITIAL_TIME = 15 * 60; // 15 minutes
  const [timeLeft, setTimeLeft] = useState(INITIAL_TIME);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let interval: any;

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(INITIAL_TIME);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="bg-gradient-to-br from-teal-500 to-teal-700 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden group">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 -mr-8 -mt-8 w-24 h-24 bg-white opacity-10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700"></div>
      
      <div className="flex items-center gap-2 mb-4 opacity-90">
        <TimerIcon size={18} />
        <span className="text-sm font-bold uppercase tracking-wide">Focus Sprint</span>
      </div>

      <div className="text-5xl font-mono font-bold mb-6 tracking-tighter tabular-nums">
        {formatTime(timeLeft)}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={toggleTimer}
          className="flex-1 bg-white text-teal-700 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-teal-50 transition-colors shadow-sm"
        >
          {isActive ? <><Pause size={18} /> Pause</> : <><Play size={18} /> Start</>}
        </button>
        <button
          onClick={resetTimer}
          className="p-3 bg-teal-800/50 hover:bg-teal-800 text-white rounded-xl transition-colors backdrop-blur-sm"
          title="Reset Timer"
        >
          <RotateCcw size={18} />
        </button>
      </div>
    </div>
  );
};

export default Timer;
