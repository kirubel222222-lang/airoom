
import React, { useCallback } from 'react';
import { Upload, X, Camera, Palette, Scan, Check } from 'lucide-react';
import { ImageState, RoomStyle } from '../types';

interface ImageUploadProps {
  imageState: ImageState;
  onImageChange: (state: ImageState) => void;
  onClear: () => void;
  isAnalyzing: boolean;
}

const STYLES: RoomStyle[] = [
  'Modern Minimalist', 
  'Bohemian', 
  'Industrial', 
  'Scandi', 
  'Cozy Clutter-Free',
  'Japandi',
  'Mid-Century Modern',
  'Biophilic',
  'Art Deco',
  'Coastal',
  'Modern Farmhouse',
  'Cyberpunk'
];

const ImageUpload: React.FC<ImageUploadProps> = ({ imageState, onImageChange, onClear, isAnalyzing }) => {
  
  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      
      onImageChange({
        ...imageState,
        file,
        previewUrl: result,
        base64,
        mimeType: file.type
      });
    };
    reader.readAsDataURL(file);
  }, [onImageChange, imageState]);

  const handleStyleSelect = (style: RoomStyle) => {
    onImageChange({
      ...imageState,
      selectedStyle: style
    });
  };

  if (imageState.previewUrl) {
    return (
      <div className="flex flex-col gap-4">
        <div className="relative w-full h-64 md:h-72 lg:h-80 rounded-2xl overflow-hidden shadow-sm border border-slate-200 group bg-slate-900 transition-all duration-500">
          <img 
            src={imageState.previewUrl} 
            alt="Room Preview" 
            className={`w-full h-full object-cover transition-transform duration-700 ${isAnalyzing ? 'scale-105 opacity-80' : 'group-hover:scale-105'}`}
          />
          
          {/* Normal State Overlays */}
          {!isAnalyzing && (
            <>
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <button 
                onClick={onClear}
                className="absolute top-3 right-3 bg-white/90 hover:bg-white text-slate-700 p-2 rounded-full shadow-md backdrop-blur-sm transition-all hover:scale-110 active:scale-95 z-20"
                title="Remove image"
              >
                <X size={20} />
              </button>
              <div className="absolute bottom-3 left-3 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-white/10 z-10">
                  <p className="text-white text-xs font-medium flex items-center gap-1.5">
                    <Camera size={14} /> Original Photo
                  </p>
              </div>
            </>
          )}

          {/* Scanning Animation Overlay */}
          {isAnalyzing && (
            <div className="absolute inset-0 z-10">
              {/* Laser Beam */}
              <div className="animate-scan"></div>
              
              {/* Tech Grid Overlay */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(45,212,191,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(45,212,191,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
              
              {/* Corner Brackets */}
              <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-teal-400 rounded-tl-lg"></div>
              <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-teal-400 rounded-tr-lg"></div>
              <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-teal-400 rounded-bl-lg"></div>
              <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-teal-400 rounded-br-lg"></div>
              
              {/* Status Text */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black/70 backdrop-blur-md text-teal-400 px-4 py-2 rounded-lg border border-teal-500/30 font-mono text-sm tracking-widest uppercase shadow-[0_0_20px_rgba(45,212,191,0.3)]">
                Scanning...
              </div>
            </div>
          )}
        </div>
        
        {/* Modern Style Selector - Horizontal Scroll Chips */}
        {!isAnalyzing && (
             <div className="bg-white/60 backdrop-blur-md border border-white/60 rounded-xl p-3 shadow-sm flex flex-col gap-2">
                <div className="flex items-center gap-2 text-slate-700 px-1">
                   <Palette size={16} className="text-teal-600" />
                   <span className="text-xs font-bold uppercase tracking-wider">Select Aesthetic</span>
                </div>
                
                <div className="flex gap-2 overflow-x-auto pb-2 pt-1 scrollbar-hide -mx-1 px-1 snap-x">
                   {STYLES.map(style => {
                     const isSelected = imageState.selectedStyle === style;
                     return (
                       <button
                         key={style}
                         onClick={() => handleStyleSelect(style)}
                         className={`
                           flex-shrink-0 px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all duration-300 snap-center border
                           ${isSelected 
                             ? 'bg-teal-600 text-white border-teal-600 shadow-lg shadow-teal-500/30 scale-105' 
                             : 'bg-white text-slate-600 border-slate-200 hover:border-teal-300 hover:bg-teal-50'}
                         `}
                       >
                         <div className="flex items-center gap-1.5">
                           {isSelected && <Check size={12} strokeWidth={3} />}
                           {style}
                         </div>
                       </button>
                     );
                   })}
                </div>
             </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 w-full">
      <div className="w-full h-56 md:h-64 lg:h-72">
        <label 
          htmlFor="room-upload" 
          className="flex flex-col items-center justify-center w-full h-full border-2 border-dashed border-slate-300 rounded-2xl cursor-pointer bg-white/40 hover:bg-white/60 hover:border-teal-400 active:bg-white/70 transition-all duration-300 group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-gradient-to-tr from-teal-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
          
          <div className="flex flex-col items-center justify-center px-4 text-center relative z-10">
            <div className="mb-4 p-4 bg-white rounded-full shadow-lg shadow-teal-100 group-hover:shadow-xl group-hover:scale-110 transition-all duration-300 text-teal-600 relative">
              <Camera className="w-8 h-8 relative z-10" />
              <div className="absolute inset-0 bg-teal-100 rounded-full animate-ping opacity-20"></div>
            </div>
            <p className="mb-1 text-lg font-bold text-slate-700 group-hover:text-teal-700 transition-colors">
              Scan Your Room
            </p>
            <p className="text-sm text-slate-500 max-w-[240px]">
              Tap to capture photo or upload from gallery
            </p>
          </div>
          <input 
            id="room-upload" 
            type="file" 
            accept="image/*"
            className="hidden" 
            onChange={handleFileChange}
          />
        </label>
      </div>
    </div>
  );
};

export default ImageUpload;
