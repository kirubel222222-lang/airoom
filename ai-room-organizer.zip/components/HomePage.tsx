
import React, { useState, useRef, useEffect } from 'react';
import { ArrowRight, Sparkles, ScanLine, Layers, CheckCircle, ChevronLeft, ChevronRight, Play } from 'lucide-react';

interface HomePageProps {
  onStart: () => void;
}

const ROOM_SCENES = [
  {
    id: 1,
    name: "Living Room",
    theme: "from-teal-500 to-blue-600",
    bgGradient: "bg-gradient-to-br from-teal-50 to-blue-50",
    beforeImg: "https://images.unsplash.com/photo-1631679706909-1844bbd07221?q=80&w=1000&auto=format&fit=crop",
    afterImg: "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?q=80&w=1000&auto=format&fit=crop",
    stats: { clutter: "High", potential: "Zen Oasis" }
  },
  {
    id: 2,
    name: "Home Office",
    theme: "from-orange-400 to-amber-600",
    bgGradient: "bg-gradient-to-br from-orange-50 to-amber-50",
    beforeImg: "https://images.unsplash.com/photo-1497215728101-856f4ea42174?q=80&w=1000&auto=format&fit=crop",
    afterImg: "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1000&auto=format&fit=crop",
    stats: { clutter: "Chaotic", potential: "Productivity Hub" }
  },
  {
    id: 3,
    name: "Bedroom",
    theme: "from-indigo-400 to-purple-600",
    bgGradient: "bg-gradient-to-br from-indigo-50 to-purple-50",
    beforeImg: "https://images.unsplash.com/photo-1522771753035-1a5b6562f329?q=80&w=1000&auto=format&fit=crop",
    afterImg: "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?q=80&w=1000&auto=format&fit=crop",
    stats: { clutter: "Messy", potential: "Sleep Sanctuary" }
  }
];

const HomePage: React.FC<HomePageProps> = ({ onStart }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [currentSlide, setCurrentSlide] = useState(0);

  const scene = ROOM_SCENES[currentSlide];

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    
    // Rotation sensitivity
    const y = ((clientX - innerWidth / 2) / innerWidth) * 30;
    const x = -((clientY - innerHeight / 2) / innerHeight) * 30;
    
    setRotation({ x, y });
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!containerRef.current) return;
    
    const touch = e.touches[0];
    const { clientX, clientY } = touch;
    const { innerWidth, innerHeight } = window;
    
    const y = ((clientX - innerWidth / 2) / innerWidth) * 30;
    const x = -((clientY - innerHeight / 2) / innerHeight) * 30;
    
    setRotation({ x, y });
  };

  const resetRotation = () => {
    setRotation({ x: 0, y: 0 });
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % ROOM_SCENES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + ROOM_SCENES.length) % ROOM_SCENES.length);
  };

  return (
    <div 
      className={`min-h-screen w-full flex flex-col items-center justify-center overflow-x-hidden relative perspective-1000 transition-colors duration-1000 ${scene.bgGradient}`}
      onMouseMove={handleMouseMove}
      onTouchMove={handleTouchMove}
      onMouseLeave={resetRotation}
      onTouchEnd={resetRotation}
    >
      {/* Background Decor - Dynamic Blobs */}
      <div className={`absolute top-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full blur-[100px] pointer-events-none transition-colors duration-1000 bg-gradient-to-r ${scene.theme} opacity-20`} />
      <div className={`absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full blur-[120px] pointer-events-none transition-colors duration-1000 bg-gradient-to-l ${scene.theme} opacity-20`} />

      <div className="max-w-7xl w-full px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-8 lg:gap-16 items-center z-10 py-10 lg:py-0">
        
        {/* Left Content - Text */}
        <div className="space-y-6 sm:space-y-8 animate-fade-in text-center lg:text-left relative z-20 order-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/60 backdrop-blur-md rounded-full border border-slate-200 shadow-sm mx-auto lg:mx-0">
            <Sparkles size={14} className="text-slate-600" />
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">AI Room Transformation</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-slate-900 tracking-tight leading-[1.1]">
            Turn Your Clutter into <span className={`text-transparent bg-clip-text bg-gradient-to-r ${scene.theme} transition-all duration-700`}>{scene.stats.potential}.</span>
          </h1>
          
          <p className="text-base sm:text-lg md:text-xl text-slate-600 max-w-xl mx-auto lg:mx-0 leading-relaxed">
            Snap a photo of your messy room. Our AI instantly visualizes a clean version and gives you a gamified checklist to get it done.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-2">
            <button 
              onClick={onStart}
              className="group relative px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold text-lg shadow-2xl shadow-slate-900/30 hover:scale-105 hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${scene.theme} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
              <div className="relative flex items-center gap-2 justify-center">
                Start Transformation <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
            
            <div className="flex items-center justify-center gap-4 px-6 py-4 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/80 shadow-sm hover:bg-white/80 transition-colors cursor-default">
               <div className="flex -space-x-2">
                 <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs">📸</div>
                 <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs">✨</div>
               </div>
               <span className="text-sm font-semibold text-slate-700">See Examples</span>
            </div>
          </div>
        </div>

        {/* Right Content - 3D Carousel (Visible on mobile now) */}
        <div className="relative h-[450px] sm:h-[500px] lg:h-[600px] flex items-center justify-center perspective-1000 w-full order-2" ref={containerRef}>
          
          {/* Carousel Controls */}
          <div className="absolute top-0 right-0 lg:right-0 z-30 flex gap-2">
             <button onClick={prevSlide} className="p-2 rounded-full bg-white/80 hover:bg-white shadow-lg text-slate-700 transition-all hover:scale-110 active:scale-95">
                <ChevronLeft size={20} />
             </button>
             <button onClick={nextSlide} className="p-2 rounded-full bg-white/80 hover:bg-white shadow-lg text-slate-700 transition-all hover:scale-110 active:scale-95">
                <ChevronRight size={20} />
             </button>
          </div>

          <div 
            className="relative w-full h-full transform-style-3d transition-transform duration-200 ease-out flex items-center justify-center"
            style={{ 
              transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` 
            }}
          >
            {/* Layer 1: Main "After" Image (Back) */}
            <div 
              className="absolute glass-panel rounded-[24px] sm:rounded-[32px] p-2 shadow-2xl transform-style-3d animate-float-slow w-[260px] h-[360px] sm:w-[340px] sm:h-[480px] lg:w-[420px] lg:h-[540px]"
              style={{ transform: 'translateZ(0px)' }}
            >
              <div className="w-full h-full rounded-[16px] sm:rounded-[24px] overflow-hidden relative border border-white/50 bg-slate-100">
                <img 
                  src={scene.afterImg}
                  alt="Organized Room" 
                  className="w-full h-full object-cover transition-opacity duration-500"
                  key={`after-${scene.id}`}
                />
                
                {/* Overlay Text */}
                <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 lg:p-8 bg-gradient-to-t from-black/80 via-black/40 to-transparent text-white">
                  <div className="flex items-center justify-between mb-1 sm:mb-2">
                    <span className="bg-white/20 backdrop-blur-md px-2 py-0.5 sm:px-3 sm:py-1 rounded-full text-[10px] sm:text-xs font-bold uppercase tracking-wide border border-white/20">After</span>
                  </div>
                  <p className="font-bold text-lg sm:text-2xl leading-tight">{scene.name} Zen</p>
                </div>
              </div>
            </div>

            {/* Layer 2: "Before" Image (Floating Top Right) */}
            <div 
              className="absolute top-4 right-4 w-28 h-28 sm:w-40 sm:h-40 lg:top-16 lg:right-0 lg:w-52 lg:h-52 glass-panel rounded-xl sm:rounded-2xl p-1.5 sm:p-2 shadow-[0_20px_50px_rgba(0,0,0,0.3)] transform-style-3d animate-float-medium"
              style={{ transform: 'translateZ(60px) translateX(10px) lg:translateX(20px) rotate(3deg)' }}
            >
               <div className="w-full h-full rounded-lg sm:rounded-xl overflow-hidden relative group border-2 border-white/80">
                <img 
                  src={scene.beforeImg} 
                  alt="Messy Room" 
                  className="w-full h-full object-cover grayscale contrast-125 transition-all duration-500"
                  key={`before-${scene.id}`}
                />
                 <div className="absolute top-2 left-2 bg-red-500 text-white text-[8px] sm:text-[10px] font-bold px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-md shadow-lg flex items-center gap-1">
                    BEFORE
                 </div>
               </div>
            </div>

            {/* Layer 3: Analysis Card (Floating Bottom Left) */}
            <div 
              className="absolute bottom-8 -left-2 w-48 sm:w-56 lg:bottom-24 lg:-left-8 lg:w-64 bg-white/90 backdrop-blur-xl rounded-xl sm:rounded-2xl p-3 sm:p-5 shadow-[0_20px_50px_rgba(0,0,0,0.15)] transform-style-3d border border-white/80 animate-float-fast"
              style={{ transform: 'translateZ(90px) rotate(-3deg)' }}
            >
              <div className="flex items-center gap-3 mb-2 sm:mb-4 border-b border-slate-100 pb-2 sm:pb-3">
                <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br ${scene.theme} flex items-center justify-center text-white shadow-sm border border-white`}>
                  <ScanLine size={16} className="sm:w-5 sm:h-5" />
                </div>
                <div>
                  <p className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-wide">Analysis Report</p>
                  <p className="text-xs sm:text-sm font-bold text-slate-800">Scan #{100 + scene.id}</p>
                </div>
              </div>
              <div className="space-y-2 sm:space-y-3">
                <div className="flex items-center justify-between text-xs sm:text-sm">
                   <span className="text-slate-600 flex items-center gap-2"><Layers size={14} /> Clutter</span>
                   <span className="font-bold text-red-500">{scene.stats.clutter}</span>
                </div>
                <div className="flex items-center justify-between text-xs sm:text-sm">
                   <span className="text-slate-600 flex items-center gap-2"><CheckCircle size={14} /> Style</span>
                   <span className={`font-bold text-transparent bg-clip-text bg-gradient-to-r ${scene.theme}`}>Minimal</span>
                </div>
                
                {/* Progress Bar */}
                <div className="mt-2 w-full bg-slate-100 rounded-full h-1 sm:h-1.5 overflow-hidden">
                    <div className={`h-full w-[85%] rounded-full bg-gradient-to-r ${scene.theme}`}></div>
                </div>
              </div>
            </div>
            
            {/* Layer 4: Floating Decorative Element (Top Left) */}
            <div 
                className={`absolute top-10 -left-2 sm:top-20 sm:-left-4 lg:top-32 lg:-left-4 w-10 h-10 sm:w-14 sm:h-14 lg:w-16 lg:h-16 bg-gradient-to-br ${scene.theme} rounded-xl sm:rounded-2xl shadow-lg flex items-center justify-center transform-style-3d animate-float-slow`}
                style={{ transform: 'translateZ(40px) rotate(-10deg)', animationDelay: '1s' }}
            >
                <Sparkles className="text-white w-5 h-5 sm:w-7 sm:h-7 lg:w-8 lg:h-8" />
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
