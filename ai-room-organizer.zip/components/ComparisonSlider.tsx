
import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { Download } from 'lucide-react';

interface ComparisonSliderProps {
  originalImage: string;
  generatedImage: string;
}

const ComparisonSlider: React.FC<ComparisonSliderProps> = ({ originalImage, generatedImage }) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(0);

  // Update container width on mount and resize to ensure the "clipped" image is the correct full size
  useLayoutEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.offsetWidth);
      }
    };

    updateWidth();
    window.addEventListener('resize', updateWidth);
    
    // Short timeout to catch layout shifts on mobile
    const timer = setTimeout(updateWidth, 100);
    
    return () => {
      window.removeEventListener('resize', updateWidth);
      clearTimeout(timer);
    };
  }, []);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = 'zenspace-organized-room.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden select-none shadow-lg border border-white/50 group touch-pan-y" ref={containerRef}>
        
        {/* Background (Generated/After Image) */}
        <img 
          src={generatedImage} 
          alt="After" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute top-4 right-4 bg-teal-600/90 text-white px-3 py-1 rounded-full text-xs font-bold shadow-sm backdrop-blur-md z-10">
          AFTER
        </div>

        {/* Foreground (Original/Before Image) - Clipped */}
        <div 
          className="absolute inset-0 w-full h-full overflow-hidden"
          style={{ width: `${sliderPosition}%` }}
        >
          <img 
            src={originalImage} 
            alt="Before" 
            className="absolute inset-0 max-w-none h-full object-cover"
            style={{ width: containerWidth || '100%' }}
          />
           <div className="absolute top-4 left-4 bg-slate-800/80 text-white px-3 py-1 rounded-full text-xs font-bold shadow-sm backdrop-blur-md">
            BEFORE
          </div>
        </div>

        {/* Slider Handle Line */}
        <div 
          className="absolute inset-y-0 w-1 bg-white cursor-ew-resize shadow-[0_0_10px_rgba(0,0,0,0.5)] touch-none"
          style={{ left: `${sliderPosition}%` }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center border-2 border-teal-500">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0d9488" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <path d="m9 18-6-6 6-6"/>
              <path d="m15 6 6 6-6 6"/>
            </svg>
          </div>
        </div>

        {/* Range Input Overlay for Interaction */}
        <input
          type="range"
          min="0"
          max="100"
          value={sliderPosition}
          onChange={(e) => setSliderPosition(Number(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20 touch-none"
        />
      </div>

      <div className="flex justify-between items-center px-2">
         <p className="text-slate-500 text-sm italic">Drag slider to compare</p>
         <button 
           onClick={handleDownload}
           className="flex items-center gap-2 text-sm font-medium text-teal-700 hover:text-teal-800 transition-colors bg-teal-50 hover:bg-teal-100 px-4 py-2 rounded-lg"
         >
           <Download size={16} /> Save Image
         </button>
      </div>
    </div>
  );
};

export default ComparisonSlider;
