
import React, { useState } from 'react';
import { LayoutGrid, AlertCircle, Sparkles, Home, Menu } from 'lucide-react';
import ImageUpload from './components/ImageUpload';
import AnalysisDisplay from './components/AnalysisDisplay';
import ChatBot from './components/ChatBot';
import HomePage from './components/HomePage'; // Import Home Page
import { ImageState, ChatMessage, AnalysisResult } from './types';
import { analyzeImage, createOrganizerChat, sendChatMessage, generateOrganizedImage } from './services/gemini';
import { Chat } from '@google/genai';

const App: React.FC = () => {
  // Navigation State
  const [view, setView] = useState<'home' | 'app'>('home');

  // App Logic State
  const [imageState, setImageState] = useState<ImageState>({
    file: null,
    previewUrl: null,
    base64: null,
    mimeType: null,
    selectedStyle: 'Modern Minimalist'
  });
  
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Chat State
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Handlers
  const handleStartApp = () => {
    setView('app');
  };

  const handleReturnHome = () => {
    setView('home');
  };

  const handleImageChange = (newState: ImageState) => {
    setImageState(newState);
    setAnalysis(null);
    setGeneratedImage(null);
    setChatSession(null);
    setChatMessages([]);
    setError(null);
  };

  const handleClearImage = () => {
    setImageState({
      file: null,
      previewUrl: null,
      base64: null,
      mimeType: null,
      selectedStyle: 'Modern Minimalist'
    });
    setAnalysis(null);
    setGeneratedImage(null);
    setChatSession(null);
    setChatMessages([]);
    setError(null);
  };

  const handleStartAnalysis = async () => {
    if (!imageState.base64 || !imageState.mimeType) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const analysisPromise = analyzeImage(imageState.base64, imageState.mimeType, imageState.selectedStyle);
      const imageGenerationPromise = generateOrganizedImage(imageState.base64, imageState.mimeType, imageState.selectedStyle);

      const [result, organizedImageUrl] = await Promise.all([analysisPromise, imageGenerationPromise]);

      setAnalysis(result);
      setGeneratedImage(organizedImageUrl);

      // Create chat based on the text part of the analysis
      const newChat = createOrganizerChat(result.markdown);
      setChatSession(newChat);
      
      setChatMessages([
        { 
          role: 'model', 
          text: `I've analyzed your room with a ${imageState.selectedStyle} approach! I've also created a task list in the "Tasks" tab to get you started. How can I help you execute this plan?` 
        }
      ]);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong during analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSendMessage = async (text: string) => {
    if (!chatSession) return;

    const userMsg: ChatMessage = { role: 'user', text };
    setChatMessages(prev => [...prev, userMsg]);
    setIsChatLoading(true);

    try {
      const responseText = await sendChatMessage(chatSession, text);
      setChatMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (err) {
      setChatMessages(prev => [
        ...prev,
        { role: 'model', text: "Sorry, I'm having trouble connecting right now.", isError: true }
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Render Home Page
  if (view === 'home') {
    return <HomePage onStart={handleStartApp} />;
  }

  // Render Main App
  return (
    <div className="min-h-screen w-full flex flex-col font-sans relative z-10 animate-fade-in bg-[#f8fafc]">
      
      {/* Navbar - Sticky on mobile */}
      <header className="flex-shrink-0 z-50 pt-2 px-2 sm:pt-4 sm:px-6 lg:px-8 pb-2 sticky top-0 lg:static">
        <div className="glass-panel max-w-[1400px] mx-auto h-14 sm:h-16 rounded-xl sm:rounded-2xl flex items-center justify-between px-4 sm:px-6 backdrop-blur-xl bg-white/70">
          <div className="flex items-center gap-2 sm:gap-3 cursor-pointer" onClick={handleReturnHome}>
            <div className="bg-gradient-to-br from-teal-500 to-teal-700 p-1.5 sm:p-2 rounded-lg sm:rounded-xl shadow-lg shadow-teal-600/20 text-white">
              <LayoutGrid className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <h1 className="text-lg sm:text-xl font-bold text-slate-800 tracking-tight">ZenSpace</h1>
          </div>
          
          <div className="flex items-center gap-2 sm:gap-3">
            <button 
              onClick={handleReturnHome}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors lg:hidden"
            >
              <Home size={18} />
            </button>

            <div className="text-xs sm:text-sm font-medium text-slate-500 hidden sm:flex items-center gap-2 bg-white/50 px-3 py-1 rounded-full border border-white/60">
              <Sparkles size={14} className="text-teal-600"/> 
              <span>AI Powered</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-[1400px] mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-4 lg:overflow-hidden flex flex-col">
        
        {error && (
          <div className="mb-4 bg-red-50/90 backdrop-blur-md border border-red-200 text-red-800 px-4 py-3 rounded-xl flex items-center gap-3 shadow-sm animate-fade-in mx-auto max-w-2xl w-full">
            <AlertCircle size={20} />
            <p className="font-medium text-sm">{error}</p>
          </div>
        )}

        {/* Mobile: Vertical Stack | Desktop: Grid */}
        <div className="flex flex-col lg:grid lg:grid-cols-12 gap-4 sm:gap-6 flex-1 lg:h-full lg:overflow-hidden pb-4 lg:pb-0">
          
          {/* Left Column: Upload & Analysis */}
          <div className="order-1 lg:col-span-7 flex flex-col gap-4 sm:gap-6 lg:h-full lg:overflow-y-auto custom-scrollbar lg:pr-1">
            <section className="flex-shrink-0">
               <ImageUpload 
                 imageState={imageState} 
                 onImageChange={handleImageChange} 
                 onClear={handleClearImage}
                 isAnalyzing={isAnalyzing}
               />
            </section>

            <section className="flex-1 min-h-[400px] sm:min-h-[500px]">
              <AnalysisDisplay 
                analysis={analysis} 
                generatedImage={generatedImage}
                originalImage={imageState.previewUrl}
                isAnalyzing={isAnalyzing} 
                onStartAnalysis={handleStartAnalysis}
                hasImage={!!imageState.previewUrl}
              />
            </section>
          </div>

          {/* Right Column: Chat - Fixed height on mobile to encourage interaction but allow scrolling elsewhere */}
          <div className="order-2 lg:col-span-5 h-[500px] sm:h-[600px] lg:h-full">
            <ChatBot 
              messages={chatMessages}
              onSendMessage={handleSendMessage}
              isLoading={isChatLoading}
              disabled={!chatSession}
            />
          </div>

        </div>
      </main>
    </div>
  );
};

export default App;
