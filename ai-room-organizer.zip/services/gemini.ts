
import { GoogleGenAI, Chat } from "@google/genai";
import { RoomStyle, AnalysisResult, DeclutterTask } from "../types";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = 'gemini-3-pro-preview';
const IMAGE_MODEL_NAME = 'gemini-2.5-flash-image';

/**
 * Analyzes an uploaded image to provide organization suggestions in JSON format.
 */
export const analyzeImage = async (base64Data: string, mimeType: string, style: RoomStyle): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Data
            }
          },
          {
            text: `You are a professional home organizer. Analyze this room photo. The user wants a "${style}" style.
            
            Return a JSON object with this exact structure:
            {
              "markdown": "A detailed analysis in Markdown format. Include: 1. Room Type & Function. 2. Storage Analysis. 3. Zen Tip.",
              "tasks": [
                { "id": "1", "zone": "Nightstand", "task": "Clear water glasses and receipts", "timeEstimate": "5 mins", "difficulty": "Easy" },
                ... (generate 4-6 specific actionable tasks)
              ]
            }
            Do not include markdown code blocks (like \`\`\`json) in the response, just the raw JSON string.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text || "{}";
    const result = JSON.parse(text);
    
    return {
      markdown: result.markdown || "Analysis not available.",
      tasks: result.tasks || []
    };

  } catch (error) {
    console.error("Analysis failed:", error);
    // Fallback if JSON parsing fails
    return {
      markdown: "I encountered an error analyzing the detailed plan, but I can still help you via chat!",
      tasks: []
    };
  }
};

/**
 * Generates a visualized "After" image of the organized room.
 */
export const generateOrganizedImage = async (base64Data: string, mimeType: string, style: RoomStyle): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: IMAGE_MODEL_NAME,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Data
            }
          },
          {
            text: `Generate a photorealistic image of this room transformed into a perfectly organized, clean, and decluttered space. 
            Maintain the exact same room structure, window placement, and flooring. 
            Apply a "${style}" interior design style.
            Remove all mess, piles, and clutter. 
            Add tasteful storage solutions that match the ${style} aesthetic.
            Ensure lighting is bright and inviting.`
          }
        ]
      }
    });

    // Iterate through parts to find the image
    if (response.candidates && response.candidates[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Image generation failed:", error);
    return null; // Fail silently for image generation
  }
};

/**
 * Creates a chat session contextually aware of the room analysis.
 */
export const createOrganizerChat = (analysisContext: string): Chat => {
  return ai.chats.create({
    model: MODEL_NAME,
    config: {
      systemInstruction: `You are ZenSpace, a friendly and expert home organizer assistant. 
      The user is looking at a photo of their room which you have just analyzed.
      
      Here is your previous analysis of the room:
      """
      ${analysisContext}
      """
      
      Answer the user's follow-up questions about organizing, design, or decluttering this specific room based on this context. 
      Keep answers concise, helpful, and encouraging. Do not repeat the full analysis unless asked.`
    }
  });
};

/**
 * Sends a message to the active chat session.
 */
export const sendChatMessage = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response = await chat.sendMessage({ message });
    return response.text || "I didn't catch that.";
  } catch (error) {
    console.error("Chat failed:", error);
    throw new Error("Failed to send message.");
  }
};
